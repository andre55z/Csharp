﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ploops
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exercício1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio1>().Count() > 0)
            {
                MessageBox.Show("Form já existe"); //da erro se forms nao tem nada
                Application.OpenForms["frmExercicio2"].BringToFront();
                //ou Application.OpenGorms["frmExercicio2"].Activate();
            }
            else
            {
                frmExercicio1 obj2 = new frmExercicio1();
                obj2.MdiParent = this;
                obj2.WindowState = FormWindowState.Maximized;
                obj2.Show();
            }
        }

        private void exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<fmrExercicio2>().Count() > 0)
            {
                MessageBox.Show("Form já existe"); //da erro se forms nao tem nada
                Application.OpenForms["frmExercicio2"].BringToFront();
                //ou Application.OpenGorms["frmExercicio2"].Activate();
            }
            else
            {
                fmrExercicio2 obj2 = new fmrExercicio2();
                obj2.MdiParent = this;
                obj2.WindowState = FormWindowState.Maximized;
                obj2.Show();
            }
        }
    }
}
