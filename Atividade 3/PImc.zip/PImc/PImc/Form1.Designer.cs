﻿namespace PImc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnCalc = new Button();
            lblImc = new Label();
            txtIMC = new TextBox();
            lblPeso = new Label();
            lblAlt = new Label();
            mskbxPeso = new MaskedTextBox();
            btnLimp = new Button();
            btnSai = new Button();
            mskbxAlt = new MaskedTextBox();
            SuspendLayout();
            // 
            // btnCalc
            // 
            btnCalc.Font = new Font("Segoe UI", 18F);
            btnCalc.Location = new Point(145, 278);
            btnCalc.Name = "btnCalc";
            btnCalc.Size = new Size(140, 87);
            btnCalc.TabIndex = 0;
            btnCalc.Text = "Calcular";
            btnCalc.UseVisualStyleBackColor = true;
            btnCalc.Click += btnCalc_Click;
            // 
            // lblImc
            // 
            lblImc.AutoSize = true;
            lblImc.Font = new Font("Segoe UI", 18F);
            lblImc.Location = new Point(62, 184);
            lblImc.Name = "lblImc";
            lblImc.Size = new Size(57, 32);
            lblImc.TabIndex = 1;
            lblImc.Text = "IMC";
            lblImc.Click += lblImc_Click;
            // 
            // txtIMC
            // 
            txtIMC.Enabled = false;
            txtIMC.Location = new Point(145, 193);
            txtIMC.Name = "txtIMC";
            txtIMC.Size = new Size(160, 23);
            txtIMC.TabIndex = 2;
            // 
            // lblPeso
            // 
            lblPeso.AutoSize = true;
            lblPeso.Font = new Font("Segoe UI", 18F);
            lblPeso.Location = new Point(58, 45);
            lblPeso.Name = "lblPeso";
            lblPeso.Size = new Size(122, 32);
            lblPeso.TabIndex = 3;
            lblPeso.Text = "Peso atual";
            lblPeso.Click += label2_Click;
            // 
            // lblAlt
            // 
            lblAlt.AutoSize = true;
            lblAlt.Font = new Font("Segoe UI", 18F);
            lblAlt.Location = new Point(62, 103);
            lblAlt.Name = "lblAlt";
            lblAlt.Size = new Size(77, 32);
            lblAlt.TabIndex = 4;
            lblAlt.Text = "Altura";
            // 
            // mskbxPeso
            // 
            mskbxPeso.Location = new Point(186, 54);
            mskbxPeso.Mask = "000.00";
            mskbxPeso.Name = "mskbxPeso";
            mskbxPeso.Size = new Size(119, 23);
            mskbxPeso.TabIndex = 6;
            mskbxPeso.MaskInputRejected += mskbxPeso_MaskInputRejected;
            mskbxPeso.Validated += mskbxPeso_Validated;
            // 
            // btnLimp
            // 
            btnLimp.Font = new Font("Segoe UI", 18F);
            btnLimp.Location = new Point(320, 278);
            btnLimp.Name = "btnLimp";
            btnLimp.Size = new Size(140, 87);
            btnLimp.TabIndex = 7;
            btnLimp.Text = "Limpar";
            btnLimp.UseVisualStyleBackColor = true;
            btnLimp.Click += btnLimp_Click;
            // 
            // btnSai
            // 
            btnSai.Font = new Font("Segoe UI", 18F);
            btnSai.Location = new Point(503, 278);
            btnSai.Name = "btnSai";
            btnSai.Size = new Size(140, 87);
            btnSai.TabIndex = 8;
            btnSai.Text = "Sair";
            btnSai.UseVisualStyleBackColor = true;
            btnSai.Click += btnSai_Click;
            // 
            // mskbxAlt
            // 
            mskbxAlt.Location = new Point(145, 112);
            mskbxAlt.Mask = "0.00";
            mskbxAlt.Name = "mskbxAlt";
            mskbxAlt.Size = new Size(160, 23);
            mskbxAlt.TabIndex = 9;
            mskbxAlt.MaskInputRejected += mskbxAlt_MaskInputRejected;
            mskbxAlt.Validated += mskbxAlt_Validated;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(mskbxAlt);
            Controls.Add(btnSai);
            Controls.Add(btnLimp);
            Controls.Add(mskbxPeso);
            Controls.Add(lblAlt);
            Controls.Add(lblPeso);
            Controls.Add(txtIMC);
            Controls.Add(lblImc);
            Controls.Add(btnCalc);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnCalc;
        private Label lblImc;
        private TextBox txtIMC;
        private Label lblPeso;
        private Label lblAlt;
        private TextBox textBox2;
        private MaskedTextBox mskbxPeso;
        private Button btnLimp;
        private Button btnSai;
        private MaskedTextBox mskbxAlt;
    }
}
