namespace PImc
{
    public partial class Form1 : Form
    {
        double peso;
        double altura;
        double imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnLimp_Click(object sender, EventArgs e)
        {
            mskbxAlt.Clear();
            mskbxPeso.Clear();
            txtIMC.Clear();
        }

        private void lblImc_Click(object sender, EventArgs e)
        {

        }

        private void mskbxAlt_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void mskbxPeso_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if ((!double.TryParse(mskbxPeso.Text, out peso)) || (peso <= 0))
            {
                MessageBox.Show("Peso inv�lido");
                Focus();

            }


        }

        private void mskbxAlt_Validated(object sender, EventArgs e)
        {
            if ((!double.TryParse(mskbxAlt.Text, out altura)) || (altura <= 0))
            {
                MessageBox.Show("Altura inv�lida");
                Focus();

            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            imc = peso / (Math.Pow(altura, 2));
            txtIMC.Text = imc.ToString("n2");

            imc = Math.Round(imc, 1);

            if (imc < 16.9)
                MessageBox.Show("bem abaixo do peso");
            else
              if (imc < 18.9)
                MessageBox.Show("abaixo do peso");
            else
              if (imc < 24.9)
                MessageBox.Show("peso normal");
            else
              if (imc < 29.9)
                MessageBox.Show("acima do peso");
            else
              if (imc < 34.9)
                MessageBox.Show("obesidade grau I");
            else
              if (imc < 40)
                MessageBox.Show("obesidade grau II");
            else
              if (imc > 40)
                MessageBox.Show("obesidade grau III");

        }

        private void btnSai_Click(object sender, EventArgs e)
        {
            Close();   
        }
    }
}
