﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pvolume
{
    public partial class Form1 : Form
    {
        Double raio;
        Double altura;
        double volume;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(txtRaio.Text, out raio)) 
            {
                MessageBox.Show("Raio inválido");
                txtRaio.Focus();
            
            
            }
            else
            {
                if (raio<=0)
                {
                    MessageBox.Show("Raio deve ser maior que zero!");
                    txtRaio.Focus();

                }
            }
        }

        private void txtAlt_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtAlt.Text, out altura))
            {
                MessageBox.Show("Altura inválida amigão");
                e.Cancel = true;
            }
            else
            {
                if(altura <=0)
                {
                    MessageBox.Show("Altura inválida zé");
                    e.Cancel = true;    
                }
            }
        }

        private void btnLimp_Validated(object sender, EventArgs e)
        {
            
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            volume = Math.PI * Math.Pow(raio, 2) * altura;
            txtVol.Text = volume.ToString("N2");

        }

        private void btnLimp_Click(object sender, EventArgs e)
        {
            txtAlt.Clear();
            txtRaio.Text = "";
            txtVol.Text = String.Empty;
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
