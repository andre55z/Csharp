﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ploops
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void richTextFrase_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int i, r;
            r = 0;
            for (i=0; i <richTextFrase.Text.Length; i++)
            {
                if (richTextFrase.Text[i] == 'R' || richTextFrase.Text[i] == 'r')
                {
                    r = r + 1;
                }
            }
            MessageBox.Show($"O número de R´s é {r}");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int i, b;
            i = 0;
            b = 0;
            while (i < richTextFrase.Text.Length )
            {
                if (richTextFrase.Text[i] == ' ')
                    b = b + 1;
                i++;
            }
            MessageBox.Show($"O numero de espaços em branco é {b}");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int i, d;
            i = 0;
            d = 0;
            do
            { 
                if (richTextFrase.Text[i] == richTextFrase.Text[i + 1])
                        d = d + 1;
                i++;

            } while (i < richTextFrase.Text.Length - 1);
            MessageBox.Show($"O numero de pares de letras iguais é {d}");
        }
    }
}
