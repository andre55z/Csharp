﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string ra = "";
            char[] resp = new char[10];
            resp[0] = 'A';
            resp[1] = 'B';
            resp[2] = 'B';
            resp[3] = 'C';
            resp[4] = 'A';
            resp[5] = 'C';
            resp[6] = 'D';
            resp[7] = 'E';
            resp[8] = 'A';
            resp[9] = 'A';
            char[,] alunos = new char[2, 10];
                
            for (int i = 0; i < 2; i++)
            {
                for (int c = 0; c < 10; c++)
                {

                    ra = Interaction.InputBox($"A resposta da questão {c+1} do aluno {i + 1}", "Digite:");
                    if (ra.Length > 1 || ra == "")
                    {
                        MessageBox.Show("Resposta inválida!");
                        c--;
                    }
                    else
                    {
                        char cara = char.Parse(ra);
                        if (!char.IsUpper(cara) || !char.IsLetter(cara)||(cara != 'A' && cara != 'B' && cara !='C' && cara !='D' && cara !='E'))
                        {
                            MessageBox.Show("Resposta inválida!");
                            c--;
                        }
                        else
                        {
                            if (resp[c] == cara)
                            {
                                listBox1.Items.Add($"O aluno {i + 1} respondeu {cara}, e a resposta era {resp[c]}, logo a resposta esta certa ");
                            }
                            else
                                listBox1.Items.Add($"O aluno {i + 1} respondeu {cara}, mas a resposta era {resp[c]}, logo a resposta esta errada ");
                        }
                    }
                }
            }
        }
    }
}
