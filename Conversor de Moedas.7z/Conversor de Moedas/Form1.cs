﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Http;
using Newtonsoft.Json.Linq;
using Microsoft.VisualBasic;
using System.IO;

namespace Conversor_de_Moedas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            listMoney.Items.Add("Cotações");
            listMoney.Items.Add("=========================================");

        }

        private void mkdData_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void txtValue_TextChanged(object sender, EventArgs e)
        {

        }

        private async void btnConv_Click(object sender, EventArgs e)
        {
            double aux;
            if (!double.TryParse(txtValue.Text, out aux))
            {
                MessageBox.Show("Valor inválido.", "Ops", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (txtValue.Text == " " || mkdData.Text == " ")
                {
                    MessageBox.Show("Os campos devem ser todos preenchidos!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    string insapi = Interaction.InputBox("1. Acesse https://exchangeratesapi.io/\n2. Crie sua conta gratuita\n3. Obtenha sua API Access Key e insira abaixo\n", "Inserir API");
                    MessageBox.Show("*Atenção: Caso seu plano seja um plano gratuito, você conseguira apenas transformar o \neuro para outras moedas, se não dará erro", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    if (insapi == " ")
                    {
                        MessageBox.Show("Sem sua API teremos um erro.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    decimal value = decimal.Parse(txtValue.Text);
                    string origcoin = cmbOrig.SelectedItem.ToString();
                    string detcoin = cmbDest.SelectedItem.ToString();

                    decimal taxa = await Obter(origcoin, detcoin, insapi);
                    if (taxa > 0)
                    {
                        decimal valconvert = taxa * value;
                        txtValest.Text = valconvert.ToString();
                    }
                    else
                    {
                        MessageBox.Show("Erro", "Ops", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }


                }
            }



        }
        private async Task<decimal> Obter(string origcoin, string detcoin, string insapi)
        {
            string api = $"https://api.exchangeratesapi.io/v1/latest?access_key={insapi}&base={origcoin}&symbols={detcoin}";

            using (HttpClient client = new HttpClient())
            {
                string resp = await client.GetStringAsync(api);
                JObject jobj = JObject.Parse(resp);


                if (jobj["rates"] != null && jobj["rates"][detcoin] != null)
                {
                    return jobj["rates"][detcoin].Value<decimal>();
                }
                else
                {
                    MessageBox.Show("Não foi possível encontrar as taxas de câmbio para as moedas especificadas.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return 0;
                }
            }


        }
        private void btnList_Click(object sender, EventArgs e)
        {
                if (txtValest.Text == " ")
                {
                    MessageBox.Show("O valor estimado se encontra vazio", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else {
                    listMoney.Items.Add($"Dia {mkdData.Text}: {txtValue.Text} {cmbOrig.SelectedItem} em {cmbDest.SelectedItem} --> {txtValest.Text} ");
                }
        }

        private void btnLimp_Click(object sender, EventArgs e)
        {
            txtValest.Text = " ";
        }

        private void btnCopy_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(txtValest.Text);
        }

        private void btnClr_Click(object sender, EventArgs e)
        {
            listMoney.Items.Clear();
        }

        private void btnEx_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog saveFileDialog = new SaveFileDialog()) 
            {
                saveFileDialog.Title = "Salvar lista de cotações";
                saveFileDialog.FileName = $"Cotações dia {mkdData.Text}";
                saveFileDialog.Filter = "Text Files (*.txt)|.*txt| All Files *.*|*.*";
                saveFileDialog.DefaultExt = ".txt";
                saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                if (saveFileDialog.ShowDialog() == DialogResult.OK) 
                {
                    string filePath = saveFileDialog.FileName;
                    File.WriteAllLines(filePath, listMoney.Items.Cast<string>());
                    MessageBox.Show("Cotações salvas!", "Oba!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
        }
    }
}
