﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private int media;

        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            double media = 0;
            Double[] media2 = new double[20];
            Double[,] notas = new double[20, 3];
            string aux = "";
            for(var aluno = 0;aluno<20; aluno++)
            {
                for (var nota = 0; nota<3;nota++)

                {
                    aux = Interaction.InputBox($"Digite a {nota+1}ª nota do aluno {aluno+1}", "Digite a nota");


                    if (!double.TryParse(aux, out notas[aluno, nota]) || notas[aluno, nota] < 0 || notas[aluno, nota] > 10)
                    {
                        MessageBox.Show("nota invalida");
                        nota--;
                    }
                    else
                    {

                        media = media + notas[aluno, nota];
                    }
                }
                media = media / 3;
                media2[aluno] = media;
                media = 0;
            }

            aux = "";
            for(int c =0; c<20; c++)
            {
                aux += "Aluno " + (c + 1).ToString() + " Média: " + media2[c].ToString("N2") + "\n";
            }
            MessageBox.Show(aux);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string aux = "";
            for (var i = 0; i < 20; i++)
            {
                aux = Interaction.InputBox("Digite o numero", "Entrada de dados");

                if (!int.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("numero invalido");
                    i--;
                }

            }

            Array.Reverse(vetor);
            aux = "";
            foreach (int x in vetor)
            {
                aux += x + "\n";
            }

            MessageBox.Show(aux);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ArrayList list = new ArrayList() { "Ana", "Andre", "debora", "Fatima", "Joao", "Janete", "Otavio", "Marcelo", "Pedro", "Thais" };
            list.Remove("Otavio");
            string aux = "";
            foreach(string s in list)
            {
                aux += s + "\n";
            }
            MessageBox.Show(aux);

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form2 Form2 = new Form2();
            Form2.ShowDialog();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form3 Form3 = new Form3();
            Form3.ShowDialog();
        }
    }
}
