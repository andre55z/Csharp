using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        Double ladoA;
        Double ladoB;
        Double ladoC;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSai_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnVer_Click(object sender, EventArgs e)
        {
            if ((ladoA < ladoB + ladoC && ladoA > Math.Abs(ladoB - ladoC)) || (ladoB < ladoA + ladoC && ladoB > Math.Abs(ladoA - ladoC))
                || (ladoC < ladoA + ladoB && ladoC > Math.Abs(ladoA - ladoB)))
            {
                if (ladoA == ladoB && ladoB == ladoC)
                    MessageBox.Show("O triangulo � equil�tero");
                else
                {
                    if (ladoA != ladoC && ladoB != ladoC && ladoA != ladoB)
                        MessageBox.Show("Trin�ngulo escaleno");
                    else
                        MessageBox.Show("Tri�ngulo is�celes");
                }








            }
            else
                MessageBox.Show("N�o � tri�ngulo");
        }

        private void txtLadoa_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtLadoa_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoa.Text, out ladoA))
            {
                MessageBox.Show("Numero inv�lido");
                txtLadoa.Focus();
            }
        }

        private void btnLimp_Click(object sender, EventArgs e)
        {
            txtLadoa.Clear();
            txtLadoc.Clear();
            txtLadob.Clear();
        }

        private void txtLadob_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadob.Text, out ladoB))
            {
                MessageBox.Show("n�mero inv�lido");
                txtLadob.Focus();
            }
        }

        private void txtLadoc_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoc.Text, out ladoC))
            {
                MessageBox.Show("N�mero inv�lido");
                txtLadoc.Focus();
            }
        }
    }
}
