﻿namespace PContato0030482411020
{
    partial class formSobre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formSobre));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblSobre = new System.Windows.Forms.Label();
            this.lblApl = new System.Windows.Forms.Label();
            this.lblGiovanni = new System.Windows.Forms.Label();
            this.lblLucas = new System.Windows.Forms.Label();
            this.lblAndre = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.Location = new System.Drawing.Point(64, 25);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(301, 400);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // lblSobre
            // 
            this.lblSobre.AutoSize = true;
            this.lblSobre.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F);
            this.lblSobre.Location = new System.Drawing.Point(383, 25);
            this.lblSobre.Name = "lblSobre";
            this.lblSobre.Size = new System.Drawing.Size(102, 37);
            this.lblSobre.TabIndex = 1;
            this.lblSobre.Text = "Sobre";
            // 
            // lblApl
            // 
            this.lblApl.AutoSize = true;
            this.lblApl.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.lblApl.Location = new System.Drawing.Point(395, 102);
            this.lblApl.Name = "lblApl";
            this.lblApl.Size = new System.Drawing.Size(283, 26);
            this.lblApl.TabIndex = 2;
            this.lblApl.Text = "Aplicação desenvolvida por:";
            // 
            // lblGiovanni
            // 
            this.lblGiovanni.AutoSize = true;
            this.lblGiovanni.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblGiovanni.Location = new System.Drawing.Point(477, 142);
            this.lblGiovanni.Name = "lblGiovanni";
            this.lblGiovanni.Size = new System.Drawing.Size(201, 20);
            this.lblGiovanni.TabIndex = 3;
            this.lblGiovanni.Text = "Giovanni Crescenzi Bogner";
            // 
            // lblLucas
            // 
            this.lblLucas.AutoSize = true;
            this.lblLucas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblLucas.Location = new System.Drawing.Point(477, 258);
            this.lblLucas.Name = "lblLucas";
            this.lblLucas.Size = new System.Drawing.Size(141, 20);
            this.lblLucas.TabIndex = 4;
            this.lblLucas.Text = "Lucas Lopes Nardi";
            // 
            // lblAndre
            // 
            this.lblAndre.AutoSize = true;
            this.lblAndre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblAndre.Location = new System.Drawing.Point(477, 199);
            this.lblAndre.Name = "lblAndre";
            this.lblAndre.Size = new System.Drawing.Size(214, 20);
            this.lblAndre.TabIndex = 5;
            this.lblAndre.Text = "André Lucca Gaem L. Robim";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.Location = new System.Drawing.Point(477, 162);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(157, 20);
            this.label1.TabIndex = 6;
            this.label1.Text = "RA: 0030482411039";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.Location = new System.Drawing.Point(477, 219);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(157, 20);
            this.label2.TabIndex = 7;
            this.label2.Text = "RA: 0030482411020";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.Location = new System.Drawing.Point(477, 278);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(157, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "RA: 0030482411007";
            // 
            // formSobre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(742, 454);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblAndre);
            this.Controls.Add(this.lblLucas);
            this.Controls.Add(this.lblGiovanni);
            this.Controls.Add(this.lblApl);
            this.Controls.Add(this.lblSobre);
            this.Controls.Add(this.pictureBox1);
            this.Name = "formSobre";
            this.Text = "formSobre";
            this.Load += new System.EventHandler(this.formSobre_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblSobre;
        private System.Windows.Forms.Label lblApl;
        private System.Windows.Forms.Label lblGiovanni;
        private System.Windows.Forms.Label lblLucas;
        private System.Windows.Forms.Label lblAndre;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}