﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics.Eventing.Reader;


namespace Gerador_de_Senhas
{
    public partial class FormG : Form

    {

        public FormG()
        {
            InitializeComponent();
            lstSenha.Items.Add("Gerenciar Senhas");
            lstSenha.Items.Add("====================");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            int aux;
            if (!int.TryParse(txtQntc.Text, out aux) && txtQntc.Text != " ")
            {
                MessageBox.Show("Insira apenas caracteres númericos inteiros", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                if (Convert.ToInt32(txtQntc.Text) > 50)
                {
                    MessageBox.Show("Insira menos que 50 caracteres", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }

        }

        private void txtPlata_Validated(object sender, EventArgs e)
        {
            double aux;
            if (double.TryParse(txtPlata.Text, out aux))
            {
                MessageBox.Show("Resposta inválida", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            else
            {
                txtPlata.Text.ToUpper();
            }
        }

        private void btnGeras_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            StringBuilder conjCara = new StringBuilder();
            if (cboxCaracespec.Checked)
            {
                string cesp = "!@#$%&*<>?";
                conjCara.Append(cesp);
            }
            if (cboxCaracmin.Checked)
            {
                string cmin = "abcdefghijklmnopqrstuvwxyz";
                conjCara.Append(cmin);
            }
            if (cboxCaracmai.Checked)
            {
                string cmai = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                conjCara.Append(cmai);
            }
            if (cboxCaracnum.Checked)
            {
                string cnum = "1234567890";
                conjCara.Append(cnum);
            }
            if (conjCara.Length == 0)
            {
                MessageBox.Show("Selecione ao menos uma opção de caracteres a incluir", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                if (txtQntc.Text.Length == 0 || txtPlata.Text.Length == 0)
                {
                    MessageBox.Show("Não se deve deixar campos em branco!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    StringBuilder senha = new StringBuilder();
                    for (int i = 0; i < Convert.ToInt32(txtQntc.Text); i++)
                    {
                        int indice = random.Next(conjCara.Length);
                        senha.Append(conjCara[indice]);
                    }
                    txtSg.Text = senha.ToString();
                }
            }
        }

        private void btnLimp_Click(object sender, EventArgs e)
        {
            txtSg.Text = string.Empty;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            lstSenha.Items.Add($"-> Senha {txtPlata.Text}: {txtSg.Text}");
        }

        private void bntSalvar_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog saveFileDialog = new SaveFileDialog())
            {
                saveFileDialog.Title = "Salvar senhas";
                saveFileDialog.FileName = $"Senhas {txtPlata.Text}";
                saveFileDialog.DefaultExt = ".txt";
                saveFileDialog.Filter = "Text Files (*.txt)|.*txt|All Files (*.*)|*.*";
                saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName;
                    File.WriteAllLines(filePath, lstSenha.Items.Cast<string>());
                    MessageBox.Show("Senhas Salvas.", "Oba!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void btnSai_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtSg.Text)) 
            { 
                Clipboard.SetText(txtSg.Text);
            }
            else
                MessageBox.Show("Campo vazio", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
