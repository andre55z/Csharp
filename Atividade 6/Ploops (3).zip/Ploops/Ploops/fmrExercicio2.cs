﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ploops
{
    public partial class fmrExercicio2 : Form
    {
        public fmrExercicio2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int N;
            Double h, aga = 0, i;

            N = int.Parse(txtN.Text);
            if (N > 0)
            {
                for (i = 1; i <= N; i++)
                {
                    h = 1 / i;
                    aga = aga + h;
                }
            }
            else
                MessageBox.Show("Numero invalido");
            MessageBox.Show($"No final, H ={aga}");
        }
    }
}
