﻿namespace Ptriangulo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblLadoa = new Label();
            btnSai = new Button();
            txtLadoc = new TextBox();
            txtLadoa = new TextBox();
            txtLadob = new TextBox();
            lblLadob = new Label();
            lblLadoc = new Label();
            btnVer = new Button();
            btnLimp = new Button();
            SuspendLayout();
            // 
            // lblLadoa
            // 
            lblLadoa.AutoSize = true;
            lblLadoa.Font = new Font("Segoe UI", 18F);
            lblLadoa.Location = new Point(103, 76);
            lblLadoa.Name = "lblLadoa";
            lblLadoa.Size = new Size(87, 32);
            lblLadoa.TabIndex = 0;
            lblLadoa.Text = "Lado A";
            // 
            // btnSai
            // 
            btnSai.Location = new Point(468, 278);
            btnSai.Name = "btnSai";
            btnSai.Size = new Size(107, 68);
            btnSai.TabIndex = 1;
            btnSai.Text = "Sair";
            btnSai.UseVisualStyleBackColor = true;
            btnSai.Click += btnSai_Click;
            // 
            // txtLadoc
            // 
            txtLadoc.Location = new Point(212, 207);
            txtLadoc.Name = "txtLadoc";
            txtLadoc.Size = new Size(154, 23);
            txtLadoc.TabIndex = 2;
            txtLadoc.Validated += txtLadoc_Validated;
            // 
            // txtLadoa
            // 
            txtLadoa.Location = new Point(212, 76);
            txtLadoa.Name = "txtLadoa";
            txtLadoa.Size = new Size(154, 23);
            txtLadoa.TabIndex = 3;
            txtLadoa.TextChanged += txtLadoa_TextChanged;
            txtLadoa.Validated += txtLadoa_Validated;
            // 
            // txtLadob
            // 
            txtLadob.Location = new Point(212, 141);
            txtLadob.Name = "txtLadob";
            txtLadob.Size = new Size(154, 23);
            txtLadob.TabIndex = 4;
            txtLadob.Validated += txtLadob_Validated;
            // 
            // lblLadob
            // 
            lblLadob.AutoSize = true;
            lblLadob.Font = new Font("Segoe UI", 18F);
            lblLadob.Location = new Point(103, 132);
            lblLadob.Name = "lblLadob";
            lblLadob.Size = new Size(86, 32);
            lblLadob.TabIndex = 5;
            lblLadob.Text = "Lado B";
            // 
            // lblLadoc
            // 
            lblLadoc.AutoSize = true;
            lblLadoc.Font = new Font("Segoe UI", 18F);
            lblLadoc.Location = new Point(103, 198);
            lblLadoc.Name = "lblLadoc";
            lblLadoc.Size = new Size(87, 32);
            lblLadoc.TabIndex = 6;
            lblLadoc.Text = "Lado C";
            // 
            // btnVer
            // 
            btnVer.Location = new Point(185, 278);
            btnVer.Name = "btnVer";
            btnVer.Size = new Size(107, 68);
            btnVer.TabIndex = 7;
            btnVer.Text = "Verificar";
            btnVer.UseVisualStyleBackColor = true;
            btnVer.Click += btnVer_Click;
            // 
            // btnLimp
            // 
            btnLimp.Location = new Point(326, 278);
            btnLimp.Name = "btnLimp";
            btnLimp.Size = new Size(107, 68);
            btnLimp.TabIndex = 8;
            btnLimp.Text = "Limpar";
            btnLimp.UseVisualStyleBackColor = true;
            btnLimp.Click += btnLimp_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnLimp);
            Controls.Add(btnVer);
            Controls.Add(lblLadoc);
            Controls.Add(lblLadob);
            Controls.Add(txtLadob);
            Controls.Add(txtLadoa);
            Controls.Add(txtLadoc);
            Controls.Add(btnSai);
            Controls.Add(lblLadoa);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblLadoa;
        private Button btnSai;
        private TextBox txtLadoc;
        private TextBox txtLadoa;
        private TextBox txtLadob;
        private Label lblLadob;
        private Label lblLadoc;
        private Button btnVer;
        private Button btnLimp;
    }
}
