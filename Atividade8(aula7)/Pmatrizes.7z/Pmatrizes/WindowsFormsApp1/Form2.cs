﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] nome = new string[10];
            string aux = "";
            int c = 0;
            for (int i = 0; i <10; i++)
            {
                aux = Interaction.InputBox($"Digite o {c+1} nome", $"Digite os nomes");
                if (aux == "")
                {
                    MessageBox.Show("Nome inválido!");
                    i--;
                }
                else {
                    nome[i] = aux;
                    string nome1 = aux.Replace(" ", "");
                    int tamanho = nome1.Length;
                    aux = "";
                    listBox1.Items.Add($"O nome: {nome[i]} tem {tamanho} letras \n");
                }
            }
        }
    }
}
