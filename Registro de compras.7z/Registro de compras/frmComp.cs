﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Registro_de_compras
{
    public partial class frmComp : Form
    {
        public frmComp()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            double aux;
            for (int i = 0; i < 1; i++)
            {
                if (double.TryParse(textBox3.Text, out aux))
                {
                    MessageBox.Show("Por favor, insira o nome do item corretamente.");
                    i--;
                }
            }
        }
    }
}
