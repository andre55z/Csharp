﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PContato0030482411020
{
    internal class Cidade
    {
        public int idCidade { get; set; }
        public string nomeCidade { get; set; }
        public string ufCidade { get; set; }

        public DataTable Listar()
        {
            SqlDataAdapter daCidade;

            DataTable dtCidade = new DataTable();

            try
            {
                daCidade = new SqlDataAdapter("SELECT * FROM CIDADE ORDER BY NOME_CIDADE", frmPrincipal.conexao);
                daCidade.Fill(dtCidade); // preencher dataset la fora
                daCidade.FillSchema(dtCidade, SchemaType.Source); // manda coisas da estrutura
            }
            catch (Exception)
            {
                throw; // cria uma exceção
            }
            return dtCidade;
        }


    }
}