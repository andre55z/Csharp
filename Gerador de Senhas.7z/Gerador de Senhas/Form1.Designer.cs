﻿namespace Gerador_de_Senhas
{
    partial class FormG
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblQntc = new System.Windows.Forms.Label();
            this.txtQntc = new System.Windows.Forms.TextBox();
            this.lblQntc2 = new System.Windows.Forms.Label();
            this.lblCont = new System.Windows.Forms.Label();
            this.lblPlata = new System.Windows.Forms.Label();
            this.cboxCaracmai = new System.Windows.Forms.CheckBox();
            this.cboxCaracmin = new System.Windows.Forms.CheckBox();
            this.cboxCaracnum = new System.Windows.Forms.CheckBox();
            this.cboxCaracespec = new System.Windows.Forms.CheckBox();
            this.btnGeras = new System.Windows.Forms.Button();
            this.lstSenha = new System.Windows.Forms.ListBox();
            this.txtPlata = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnLimp = new System.Windows.Forms.Button();
            this.btnOk = new System.Windows.Forms.Button();
            this.txtSg = new System.Windows.Forms.TextBox();
            this.bntSalvar = new System.Windows.Forms.Button();
            this.btnSai = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblQntc
            // 
            this.lblQntc.AutoSize = true;
            this.lblQntc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQntc.Location = new System.Drawing.Point(8, 55);
            this.lblQntc.Name = "lblQntc";
            this.lblQntc.Size = new System.Drawing.Size(263, 20);
            this.lblQntc.TabIndex = 0;
            this.lblQntc.Text = "Insira quantos caracteres deseja ter";
            // 
            // txtQntc
            // 
            this.txtQntc.Location = new System.Drawing.Point(12, 99);
            this.txtQntc.Name = "txtQntc";
            this.txtQntc.Size = new System.Drawing.Size(41, 20);
            this.txtQntc.TabIndex = 2;
            this.txtQntc.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            this.txtQntc.Validated += new System.EventHandler(this.textBox1_Validated);
            // 
            // lblQntc2
            // 
            this.lblQntc2.AutoSize = true;
            this.lblQntc2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQntc2.Location = new System.Drawing.Point(8, 75);
            this.lblQntc2.Name = "lblQntc2";
            this.lblQntc2.Size = new System.Drawing.Size(109, 20);
            this.lblQntc2.TabIndex = 3;
            this.lblQntc2.Text = "em sua senha";
            // 
            // lblCont
            // 
            this.lblCont.AutoSize = true;
            this.lblCont.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCont.Location = new System.Drawing.Point(8, 135);
            this.lblCont.Name = "lblCont";
            this.lblCont.Size = new System.Drawing.Size(107, 20);
            this.lblCont.TabIndex = 4;
            this.lblCont.Text = "Deseja incluir:";
            // 
            // lblPlata
            // 
            this.lblPlata.AutoSize = true;
            this.lblPlata.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlata.Location = new System.Drawing.Point(8, 285);
            this.lblPlata.Name = "lblPlata";
            this.lblPlata.Size = new System.Drawing.Size(226, 20);
            this.lblPlata.TabIndex = 8;
            this.lblPlata.Text = "É a senha de qual plataforma?";
            // 
            // cboxCaracmai
            // 
            this.cboxCaracmai.AutoSize = true;
            this.cboxCaracmai.Location = new System.Drawing.Point(12, 169);
            this.cboxCaracmai.Name = "cboxCaracmai";
            this.cboxCaracmai.Size = new System.Drawing.Size(133, 17);
            this.cboxCaracmai.TabIndex = 10;
            this.cboxCaracmai.Text = "Caracteres Maiúsculos";
            this.cboxCaracmai.UseVisualStyleBackColor = true;
            // 
            // cboxCaracmin
            // 
            this.cboxCaracmin.AutoSize = true;
            this.cboxCaracmin.Location = new System.Drawing.Point(12, 192);
            this.cboxCaracmin.Name = "cboxCaracmin";
            this.cboxCaracmin.Size = new System.Drawing.Size(133, 17);
            this.cboxCaracmin.TabIndex = 11;
            this.cboxCaracmin.Text = "Caracteres Minúsculos";
            this.cboxCaracmin.UseVisualStyleBackColor = true;
            // 
            // cboxCaracnum
            // 
            this.cboxCaracnum.AutoSize = true;
            this.cboxCaracnum.Location = new System.Drawing.Point(12, 215);
            this.cboxCaracnum.Name = "cboxCaracnum";
            this.cboxCaracnum.Size = new System.Drawing.Size(130, 17);
            this.cboxCaracnum.TabIndex = 12;
            this.cboxCaracnum.Text = "Caracteres Numéricos";
            this.cboxCaracnum.UseVisualStyleBackColor = true;
            // 
            // cboxCaracespec
            // 
            this.cboxCaracespec.AutoSize = true;
            this.cboxCaracespec.Location = new System.Drawing.Point(12, 238);
            this.cboxCaracespec.Name = "cboxCaracespec";
            this.cboxCaracespec.Size = new System.Drawing.Size(125, 17);
            this.cboxCaracespec.TabIndex = 13;
            this.cboxCaracespec.Text = "Caracteres Especiais";
            this.cboxCaracespec.UseVisualStyleBackColor = true;
            // 
            // btnGeras
            // 
            this.btnGeras.BackColor = System.Drawing.Color.Chartreuse;
            this.btnGeras.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGeras.Location = new System.Drawing.Point(13, 375);
            this.btnGeras.Name = "btnGeras";
            this.btnGeras.Size = new System.Drawing.Size(176, 63);
            this.btnGeras.TabIndex = 14;
            this.btnGeras.Text = "Gerar Senha";
            this.btnGeras.UseVisualStyleBackColor = false;
            this.btnGeras.Click += new System.EventHandler(this.btnGeras_Click);
            // 
            // lstSenha
            // 
            this.lstSenha.FormattingEnabled = true;
            this.lstSenha.Location = new System.Drawing.Point(458, 55);
            this.lstSenha.Name = "lstSenha";
            this.lstSenha.Size = new System.Drawing.Size(258, 316);
            this.lstSenha.TabIndex = 15;
            // 
            // txtPlata
            // 
            this.txtPlata.Location = new System.Drawing.Point(12, 308);
            this.txtPlata.Name = "txtPlata";
            this.txtPlata.Size = new System.Drawing.Size(124, 20);
            this.txtPlata.TabIndex = 9;
            this.txtPlata.Validated += new System.EventHandler(this.txtPlata_Validated);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(216, 375);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 20);
            this.label1.TabIndex = 17;
            this.label1.Text = "Senha sugerida";
            // 
            // btnLimp
            // 
            this.btnLimp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnLimp.Location = new System.Drawing.Point(253, 422);
            this.btnLimp.Name = "btnLimp";
            this.btnLimp.Size = new System.Drawing.Size(58, 23);
            this.btnLimp.TabIndex = 18;
            this.btnLimp.Text = "Limpar";
            this.btnLimp.UseVisualStyleBackColor = false;
            this.btnLimp.Click += new System.EventHandler(this.btnLimp_Click);
            // 
            // btnOk
            // 
            this.btnOk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnOk.Location = new System.Drawing.Point(217, 422);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(30, 23);
            this.btnOk.TabIndex = 19;
            this.btnOk.Text = "OK";
            this.btnOk.UseVisualStyleBackColor = false;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // txtSg
            // 
            this.txtSg.Location = new System.Drawing.Point(220, 398);
            this.txtSg.Name = "txtSg";
            this.txtSg.Size = new System.Drawing.Size(117, 20);
            this.txtSg.TabIndex = 20;
            // 
            // bntSalvar
            // 
            this.bntSalvar.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.bntSalvar.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bntSalvar.Location = new System.Drawing.Point(458, 378);
            this.bntSalvar.Name = "bntSalvar";
            this.bntSalvar.Size = new System.Drawing.Size(96, 40);
            this.bntSalvar.TabIndex = 21;
            this.bntSalvar.Text = "Salvar";
            this.bntSalvar.UseVisualStyleBackColor = false;
            this.bntSalvar.Click += new System.EventHandler(this.bntSalvar_Click);
            // 
            // btnSai
            // 
            this.btnSai.BackColor = System.Drawing.Color.Red;
            this.btnSai.Location = new System.Drawing.Point(620, 378);
            this.btnSai.Name = "btnSai";
            this.btnSai.Size = new System.Drawing.Size(96, 40);
            this.btnSai.TabIndex = 22;
            this.btnSai.Text = "Sair";
            this.btnSai.UseVisualStyleBackColor = false;
            this.btnSai.Click += new System.EventHandler(this.btnSai_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button1.Location = new System.Drawing.Point(343, 398);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(50, 23);
            this.button1.TabIndex = 23;
            this.button1.Text = "Copiar";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // FormG
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnSai);
            this.Controls.Add(this.bntSalvar);
            this.Controls.Add(this.txtSg);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.btnLimp);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lstSenha);
            this.Controls.Add(this.btnGeras);
            this.Controls.Add(this.cboxCaracespec);
            this.Controls.Add(this.cboxCaracnum);
            this.Controls.Add(this.cboxCaracmin);
            this.Controls.Add(this.cboxCaracmai);
            this.Controls.Add(this.txtPlata);
            this.Controls.Add(this.lblPlata);
            this.Controls.Add(this.lblCont);
            this.Controls.Add(this.lblQntc2);
            this.Controls.Add(this.txtQntc);
            this.Controls.Add(this.lblQntc);
            this.Name = "FormG";
            this.Text = "Gerador de Senhas";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblQntc;
        private System.Windows.Forms.TextBox txtQntc;
        private System.Windows.Forms.Label lblQntc2;
        private System.Windows.Forms.Label lblCont;
        private System.Windows.Forms.Label lblPlata;
        private System.Windows.Forms.CheckBox cboxCaracmai;
        private System.Windows.Forms.CheckBox cboxCaracmin;
        private System.Windows.Forms.CheckBox cboxCaracnum;
        private System.Windows.Forms.CheckBox cboxCaracespec;
        private System.Windows.Forms.Button btnGeras;
        private System.Windows.Forms.ListBox lstSenha;
        private System.Windows.Forms.TextBox txtPlata;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnLimp;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.TextBox txtSg;
        private System.Windows.Forms.Button bntSalvar;
        private System.Windows.Forms.Button btnSai;
        private System.Windows.Forms.Button button1;
    }
}

