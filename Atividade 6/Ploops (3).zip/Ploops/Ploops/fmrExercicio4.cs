﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ploops
{
    public partial class fmrExercicio4 : Form
    {
        public fmrExercicio4()
        {
            InitializeComponent();
        }

        private void fmrExercicio4_Load(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int b, c, d;
            double a, salbrut, totgra;
            int prod = int.Parse(txtProd.Text);
            if (prod >= 100)
            {
                b = 1;
                if (prod >= 120)
                {
                    c = 1;
                    if (prod >= 150)
                        d = 1;
                    else
                        d = 0;
                }
                else
                    c = 0;
            }
            else
            {
                b = 0;
                c = 0;
                d = 0;
            }

            a = double.Parse(txtSal.Text);
            totgra = double.Parse(txtGra1.Text);
            if (prod>=150)
                salbrut = a + a * (0.05 * b + 0.1 * 1 + 0.1 * c);
            else
                salbrut = a + a * (0.05 * b + 0.1 * 0 + 0.1 * c);

            if (salbrut >= 7000 && prod < 150)
                MessageBox.Show("Atenção! Funcionários com salário maior ou igual a R$7000 e com produção menor que 150 devem ser revisados!");
            MessageBox.Show($"O salário bruto é {salbrut}");
                
        }

        private void txtGra_Click(object sender, EventArgs e)
        {

        }
    }
}
