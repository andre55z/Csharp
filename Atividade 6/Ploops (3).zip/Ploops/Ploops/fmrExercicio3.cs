﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ploops
{
    public partial class fmrExercicio3 : Form
    {
        public fmrExercicio3()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string palavrajunta = txtPala.Text.Replace(" ", "");
            string palavrapequena = palavrajunta.ToLower();
            char[] vetor = palavrapequena.ToCharArray(); 
            Array.Reverse(vetor);                
            string plavrainvertida = new string(vetor);
            if (plavrainvertida == palavrapequena)
            {
                MessageBox.Show("É palíndromo");
            }
            else
                MessageBox.Show("Não é palíndromo");
        }
    }
}
