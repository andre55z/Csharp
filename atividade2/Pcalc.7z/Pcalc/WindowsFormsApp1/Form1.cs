﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            errorProvider2.SetError(txtN2, "");
            resultado = numero1 - numero2;
            txtN3.Text = resultado.ToString("");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            errorProvider2.SetError(txtN2, "");
            resultado = numero1 / numero2;
            txtN3.Text = resultado.ToString("");
            if (numero1 == 0 || numero2 == 0)
            {
                MessageBox.Show("Não se divide por 0", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtN2.Text = "";
                txtN1.Text = "";
                txtN1.Focus();
                txtN2.Focus();
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            errorProvider2.SetError(txtN2, "");
            resultado = numero1 * numero2;
            txtN3.Text = resultado.ToString("");
        }

        private void lblRes_Click(object sender, EventArgs e)
        {

        }

        private void lblN1_Click(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            errorProvider2.SetError(txtN2, "");
            resultado = numero1 + numero2;
            txtN3.Text = resultado.ToString("");  
        }

        private void btnSai_Click(object sender, EventArgs e)
        {
            if ( MessageBox.Show("Deseja mesmo sair?", "Tem certeza?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes )
            {
                Close();
            }
            
        }

        private void btnCl_Click(object sender, EventArgs e)
        {
            txtN1.Clear();
            txtN2.Clear();
        }

        private void txtN2_Validated(object sender, EventArgs e)
        {
            try
            {
                numero2 = Convert.ToDouble(txtN2.Text);
            }
            catch(Exception ex) 
            {
                errorProvider2.SetError(txtN2, "Número 2 inválido");
                MessageBox.Show("Número inválido");
                txtN2.Focus();
            }
        }

        private void txtN3_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtN1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtN1.Text, out numero1))
            {
                errorProvider1.SetError(txtN1, "Número 1 inválido");

                MessageBox.Show("Número inválido");
                txtN1.Focus();
            }
            else
                errorProvider1.SetError(txtN1, "");
        }
    }
}
