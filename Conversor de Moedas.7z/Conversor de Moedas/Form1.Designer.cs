﻿namespace Conversor_de_Moedas
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnConv = new System.Windows.Forms.Button();
            this.cmbDest = new System.Windows.Forms.ComboBox();
            this.mkdData = new System.Windows.Forms.MaskedTextBox();
            this.txtValue = new System.Windows.Forms.TextBox();
            this.cmbOrig = new System.Windows.Forms.ComboBox();
            this.lblData = new System.Windows.Forms.Label();
            this.lblValue = new System.Windows.Forms.Label();
            this.lbOrig = new System.Windows.Forms.Label();
            this.lblDest = new System.Windows.Forms.Label();
            this.lblValtemp = new System.Windows.Forms.Label();
            this.txtValest = new System.Windows.Forms.TextBox();
            this.listMoney = new System.Windows.Forms.ListBox();
            this.btnList = new System.Windows.Forms.Button();
            this.btnLimp = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCopy = new System.Windows.Forms.Button();
            this.btnEx = new System.Windows.Forms.Button();
            this.btnClr = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnConv
            // 
            this.btnConv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnConv.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConv.Location = new System.Drawing.Point(12, 336);
            this.btnConv.Name = "btnConv";
            this.btnConv.Size = new System.Drawing.Size(159, 85);
            this.btnConv.TabIndex = 0;
            this.btnConv.Text = "Converter!";
            this.btnConv.UseVisualStyleBackColor = false;
            this.btnConv.Click += new System.EventHandler(this.btnConv_Click);
            // 
            // cmbDest
            // 
            this.cmbDest.FormattingEnabled = true;
            this.cmbDest.Items.AddRange(new object[] {
            "USD",
            "EUR",
            "BRL",
            "GBP",
            "JPY"});
            this.cmbDest.Location = new System.Drawing.Point(12, 255);
            this.cmbDest.Name = "cmbDest";
            this.cmbDest.Size = new System.Drawing.Size(121, 21);
            this.cmbDest.TabIndex = 1;
            // 
            // mkdData
            // 
            this.mkdData.Location = new System.Drawing.Point(12, 50);
            this.mkdData.Mask = "00/00/0000";
            this.mkdData.Name = "mkdData";
            this.mkdData.Size = new System.Drawing.Size(68, 20);
            this.mkdData.TabIndex = 2;
            this.mkdData.ValidatingType = typeof(System.DateTime);
            this.mkdData.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.mkdData_MaskInputRejected);
            // 
            // txtValue
            // 
            this.txtValue.Location = new System.Drawing.Point(12, 116);
            this.txtValue.Name = "txtValue";
            this.txtValue.Size = new System.Drawing.Size(100, 20);
            this.txtValue.TabIndex = 3;
            this.txtValue.TextChanged += new System.EventHandler(this.txtValue_TextChanged);
            // 
            // cmbOrig
            // 
            this.cmbOrig.FormattingEnabled = true;
            this.cmbOrig.Items.AddRange(new object[] {
            "USD",
            "EUR",
            "BRL",
            "GBP",
            "JPY"});
            this.cmbOrig.Location = new System.Drawing.Point(12, 186);
            this.cmbOrig.Name = "cmbOrig";
            this.cmbOrig.Size = new System.Drawing.Size(121, 21);
            this.cmbOrig.TabIndex = 4;
            // 
            // lblData
            // 
            this.lblData.AutoSize = true;
            this.lblData.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblData.Location = new System.Drawing.Point(12, 27);
            this.lblData.Name = "lblData";
            this.lblData.Size = new System.Drawing.Size(153, 20);
            this.lblData.TabIndex = 5;
            this.lblData.Text = "Insira a data de hoje";
            // 
            // lblValue
            // 
            this.lblValue.AutoSize = true;
            this.lblValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValue.Location = new System.Drawing.Point(8, 93);
            this.lblValue.Name = "lblValue";
            this.lblValue.Size = new System.Drawing.Size(194, 20);
            this.lblValue.TabIndex = 6;
            this.lblValue.Text = "Qual valor quer converter?";
            // 
            // lbOrig
            // 
            this.lbOrig.AutoSize = true;
            this.lbOrig.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbOrig.Location = new System.Drawing.Point(8, 163);
            this.lbOrig.Name = "lbOrig";
            this.lbOrig.Size = new System.Drawing.Size(219, 20);
            this.lbOrig.TabIndex = 7;
            this.lbOrig.Text = "Selecione a moeda de origem";
            // 
            // lblDest
            // 
            this.lblDest.AutoSize = true;
            this.lblDest.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDest.Location = new System.Drawing.Point(8, 232);
            this.lblDest.Name = "lblDest";
            this.lblDest.Size = new System.Drawing.Size(223, 20);
            this.lblDest.TabIndex = 8;
            this.lblDest.Text = "Selecione a moeda de destino";
            // 
            // lblValtemp
            // 
            this.lblValtemp.AutoSize = true;
            this.lblValtemp.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValtemp.Location = new System.Drawing.Point(199, 362);
            this.lblValtemp.Name = "lblValtemp";
            this.lblValtemp.Size = new System.Drawing.Size(102, 17);
            this.lblValtemp.TabIndex = 9;
            this.lblValtemp.Text = "Valor estimado";
            // 
            // txtValest
            // 
            this.txtValest.Location = new System.Drawing.Point(202, 383);
            this.txtValest.Name = "txtValest";
            this.txtValest.Size = new System.Drawing.Size(100, 20);
            this.txtValest.TabIndex = 10;
            // 
            // listMoney
            // 
            this.listMoney.FormattingEnabled = true;
            this.listMoney.Location = new System.Drawing.Point(436, 50);
            this.listMoney.Name = "listMoney";
            this.listMoney.Size = new System.Drawing.Size(324, 264);
            this.listMoney.TabIndex = 11;
            // 
            // btnList
            // 
            this.btnList.BackColor = System.Drawing.Color.Cyan;
            this.btnList.Location = new System.Drawing.Point(309, 379);
            this.btnList.Name = "btnList";
            this.btnList.Size = new System.Drawing.Size(50, 23);
            this.btnList.TabIndex = 12;
            this.btnList.Text = "Listar";
            this.btnList.UseVisualStyleBackColor = false;
            this.btnList.Click += new System.EventHandler(this.btnList_Click);
            // 
            // btnLimp
            // 
            this.btnLimp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnLimp.Location = new System.Drawing.Point(202, 409);
            this.btnLimp.Name = "btnLimp";
            this.btnLimp.Size = new System.Drawing.Size(47, 23);
            this.btnLimp.TabIndex = 13;
            this.btnLimp.Text = "Limpar";
            this.btnLimp.UseVisualStyleBackColor = false;
            this.btnLimp.Click += new System.EventHandler(this.btnLimp_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.Blue;
            this.btnSave.Location = new System.Drawing.Point(436, 320);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(104, 59);
            this.btnSave.TabIndex = 14;
            this.btnSave.Text = "Salvar";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCopy
            // 
            this.btnCopy.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnCopy.Location = new System.Drawing.Point(255, 409);
            this.btnCopy.Name = "btnCopy";
            this.btnCopy.Size = new System.Drawing.Size(46, 23);
            this.btnCopy.TabIndex = 15;
            this.btnCopy.Text = "Copiar";
            this.btnCopy.UseVisualStyleBackColor = false;
            this.btnCopy.Click += new System.EventHandler(this.btnCopy_Click);
            // 
            // btnEx
            // 
            this.btnEx.BackColor = System.Drawing.Color.Red;
            this.btnEx.Location = new System.Drawing.Point(656, 320);
            this.btnEx.Name = "btnEx";
            this.btnEx.Size = new System.Drawing.Size(104, 59);
            this.btnEx.TabIndex = 16;
            this.btnEx.Text = "Sair";
            this.btnEx.UseVisualStyleBackColor = false;
            this.btnEx.Click += new System.EventHandler(this.btnEx_Click);
            // 
            // btnClr
            // 
            this.btnClr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnClr.Location = new System.Drawing.Point(546, 320);
            this.btnClr.Name = "btnClr";
            this.btnClr.Size = new System.Drawing.Size(104, 59);
            this.btnClr.TabIndex = 17;
            this.btnClr.Text = "Limpar";
            this.btnClr.UseVisualStyleBackColor = false;
            this.btnClr.Click += new System.EventHandler(this.btnClr_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnClr);
            this.Controls.Add(this.btnEx);
            this.Controls.Add(this.btnCopy);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnLimp);
            this.Controls.Add(this.btnList);
            this.Controls.Add(this.listMoney);
            this.Controls.Add(this.txtValest);
            this.Controls.Add(this.lblValtemp);
            this.Controls.Add(this.lblDest);
            this.Controls.Add(this.lbOrig);
            this.Controls.Add(this.lblValue);
            this.Controls.Add(this.lblData);
            this.Controls.Add(this.cmbOrig);
            this.Controls.Add(this.txtValue);
            this.Controls.Add(this.mkdData);
            this.Controls.Add(this.cmbDest);
            this.Controls.Add(this.btnConv);
            this.Name = "Form1";
            this.Text = "Conversor de Moedas";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnConv;
        private System.Windows.Forms.ComboBox cmbDest;
        private System.Windows.Forms.MaskedTextBox mkdData;
        private System.Windows.Forms.TextBox txtValue;
        private System.Windows.Forms.ComboBox cmbOrig;
        private System.Windows.Forms.Label lblData;
        private System.Windows.Forms.Label lblValue;
        private System.Windows.Forms.Label lbOrig;
        private System.Windows.Forms.Label lblDest;
        private System.Windows.Forms.Label lblValtemp;
        private System.Windows.Forms.TextBox txtValest;
        private System.Windows.Forms.ListBox listMoney;
        private System.Windows.Forms.Button btnList;
        private System.Windows.Forms.Button btnLimp;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCopy;
        private System.Windows.Forms.Button btnEx;
        private System.Windows.Forms.Button btnClr;
    }
}

